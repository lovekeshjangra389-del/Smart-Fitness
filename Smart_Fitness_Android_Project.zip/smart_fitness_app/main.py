import os
import datetime

from kivy.app import App
from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.lang import Builder
from kivy.storage.jsonstore import JsonStore
from kivy.uix.button import Button
from kivy.uix.screenmanager import Screen

# ---------------------------------------------------------------
# Exercise data (aap yahan apni exercises add/edit kar sakte hain)
# ---------------------------------------------------------------
EXERCISES = {
    "Jumping Jacks": {
        "secs": 60,
        "info": "1. Seedhe khade ho, pair milao.\n"
                "2. Kood kar pair failao, haath sir ke upar le jao.\n"
                "3. Wapas kood kar pehli position me aao.\n"
                "Tip: Saans normal rakho, halki landing karo.",
    },
    "Push-ups": {
        "secs": 45,
        "info": "1. Haath kandhe ke barabar zameen par rakho.\n"
                "2. Body ko sidha rakho (sir se pair tak).\n"
                "3. Seena zameen ke paas le jao, phir upar dhakko.\n"
                "Tip: Aasan karne ke liye ghutne zameen par rakh sakte ho.",
    },
    "Squats": {
        "secs": 60,
        "info": "1. Pair kandhe jitne khule rakho.\n"
                "2. Kursi par baithne jaisa neeche jao.\n"
                "3. Ghutne pair ki ungliyon se aage na jaye.\n"
                "4. Edi dabake wapas upar aao.",
    },
    "Plank": {
        "secs": 40,
        "info": "1. Kohni kandhe ke neeche rakho.\n"
                "2. Body ek seedhi line me, pet andar.\n"
                "3. Kamar na jhukao, na uthao.\n"
                "Tip: Saans lete raho, rokna mat.",
    },
    "Lunges": {
        "secs": 60,
        "info": "1. Ek pair aage rakho, ek peeche.\n"
                "2. Dono ghutne 90 degree tak mode.\n"
                "3. Wapas upar aao, pair badal lo.",
    },
    "Mountain Climbers": {
        "secs": 45,
        "info": "1. Push-up position me aao.\n"
                "2. Ek-ek ghutna tezi se seene ki taraf lao.\n"
                "3. Kamar sthir rakho, tez speed se badlo.",
    },
    "Stretching / Cool-down": {
        "secs": 120,
        "info": "1. Gardan, kandhe, kamar aur pairon ko dheere kheencho.\n"
                "2. Har stretch 15-20 second rokein.\n"
                "3. Gehri saans lo, relax raho.",
    },
}

ACTIVITY = {
    "Kam active (desk job)": 1.2,
    "Halka active (1-3 din)": 1.375,
    "Madhyam active (3-5 din)": 1.55,
    "Bahut active (6-7 din)": 1.725,
}


# ---------------------------------------------------------------
# Music Player
# ---------------------------------------------------------------
class MusicPlayer:
    def __init__(self):
        self.tracks = []
        self.idx = -1
        self.sound = None
        self.pos = 0

    def add(self, path):
        if path and os.path.isfile(path) and path not in self.tracks:
            self.tracks.append(path)

    def load_folder(self, folder):
        if os.path.isdir(folder):
            for f in sorted(os.listdir(folder)):
                if f.lower().endswith((".mp3", ".wav", ".ogg", ".m4a")):
                    self.add(os.path.join(folder, f))

    def playing(self):
        return bool(self.sound and self.sound.state == "play")

    def play(self, i=None):
        if not self.tracks:
            return False
        if i is None:
            i = self.idx if self.idx >= 0 else 0
        else:
            self.pos = 0
        self.stop()
        self.idx = i % len(self.tracks)
        snd = SoundLoader.load(self.tracks[self.idx])
        if not snd:
            return False
        self.sound = snd
        snd.bind(on_stop=self._ended)
        snd.play()
        if self.pos:
            snd.seek(self.pos)
            self.pos = 0
        return True

    def _ended(self, *args):
        self.next()  # gaana khatam hone par agla gaana

    def stop(self):
        if self.sound:
            self.sound.unbind(on_stop=self._ended)
            self.sound.stop()
            self.sound = None

    def toggle(self):
        if self.playing():
            self.pos = self.sound.get_pos()
            self.stop()
        else:
            self.play()

    def next(self):
        if self.tracks:
            self.play(self.idx + 1)

    def prev(self):
        if self.tracks:
            self.play(self.idx - 1)

    def name(self):
        if 0 <= self.idx < len(self.tracks):
            return os.path.basename(self.tracks[self.idx])
        return "Koi gaana select nahi"


# ---------------------------------------------------------------
# Screens
# ---------------------------------------------------------------
class HealthScreen(Screen):
    def on_pre_enter(self, *args):
        app = App.get_running_app()
        if app.store.exists("profile"):
            p = app.store.get("profile")
            self.ids.age.text = str(p["age"])
            self.ids.height.text = str(p["height"])
            self.ids.weight.text = str(p["weight"])
            self.ids.gender.text = p["gender"]
            self.ids.activity.text = p["activity"]

    def calculate(self):
        try:
            age = int(self.ids.age.text)
            h = float(self.ids.height.text)
            w = float(self.ids.weight.text)
        except ValueError:
            self.ids.result.text = "Please umar, height aur weight sahi bharein."
            return
        if age <= 0 or h <= 0 or w <= 0:
            self.ids.result.text = "Sab values 0 se zyada honi chahiye."
            return

        gender = self.ids.gender.text
        act = self.ids.activity.text
        bmi = w / ((h / 100) ** 2)
        if bmi < 18.5:
            cat = "Underweight (kam wazan)"
        elif bmi < 25:
            cat = "Normal (healthy)"
        elif bmi < 30:
            cat = "Overweight"
        else:
            cat = "Obese"

        # Mifflin-St Jeor formula
        bmr = 10 * w + 6.25 * h - 5 * age + (5 if gender == "Male" else -161)
        calories = bmr * ACTIVITY[act]
        water = w * 0.035  # litre/din (approx)
        ideal_low = 18.5 * (h / 100) ** 2
        ideal_high = 24.9 * (h / 100) ** 2

        if age < 18:
            result_text = (
                f"BMI number: {bmi:.1f}\n"
                f"Pani ka rough estimate: {water:.1f} litre/din\n\n"
                "18 saal se kam umar mein adult BMI categories, ideal-weight range aur calorie targets sahi guide nahi hote. "
                "Apni growth aur health ke liye doctor/qualified health professional se salah lein."
            )
        else:
            result_text = (
                f"BMI: {bmi:.1f}  ->  {cat}\n"
                f"Estimated weight range (BMI-based): {ideal_low:.0f} - {ideal_high:.0f} kg\n"
                f"BMR estimate: {bmr:.0f} kcal/din\n"
                f"Daily calorie estimate: {calories:.0f} kcal\n"
                f"Water estimate: {water:.1f} litre/din\n\n"
                "Ye general estimates hain, medical advice nahi. Pyaas, mausam aur activity ke hisaab se pani ki zarurat badal sakti hai."
            )
        self.ids.result.text = result_text
        App.get_running_app().store.put(
            "profile", age=age, height=h, weight=w, gender=gender, activity=act
        )


class WorkoutScreen(Screen):
    remaining = 0
    event = None

    def show_info(self, name):
        ex = EXERCISES.get(name)
        if ex:
            self.ids.info.text = ex["info"]
            self.ids.timer.text = self.fmt(ex["secs"])

    @staticmethod
    def fmt(s):
        return f"{s // 60:02d}:{s % 60:02d}"

    def toggle(self):
        app = App.get_running_app()
        if self.event:
            self.finish(app, completed=False)
            return
        name = self.ids.spin.text
        if name not in EXERCISES:
            return
        self.remaining = EXERCISES[name]["secs"]
        self.ids.start_btn.text = "Stop"
        if self.ids.music_on.active:
            if not app.player.tracks:
                self.ids.info.text = ("Music tab me gaane add karein, "
                                      "phir workout music chalega.\n\n"
                                      + EXERCISES[name]["info"])
            elif not app.player.playing():
                app.player.play()
        self.event = Clock.schedule_interval(self.tick, 1)

    def tick(self, dt):
        self.remaining -= 1
        self.ids.timer.text = self.fmt(max(self.remaining, 0))
        if self.remaining <= 0:
            self.finish(App.get_running_app(), completed=True)

    def finish(self, app, completed):
        if self.event:
            self.event.cancel()
            self.event = None
        self.ids.start_btn.text = "Start"
        if self.ids.music_on.active:
            app.player.stop()
        if completed:
            name = self.ids.spin.text
            mins = EXERCISES[name]["secs"] / 60
            app.add_workout_minutes(mins)
            self.ids.timer.text = "Shabash! Done"
        else:
            self.show_info(self.ids.spin.text)


class MusicScreen(Screen):
    def on_pre_enter(self, *args):
        self.refresh()

    def refresh(self):
        app = App.get_running_app()
        box = self.ids.tracklist
        box.clear_widgets()
        for i, path in enumerate(app.player.tracks):
            b = Button(text=os.path.basename(path), size_hint_y=None, height="44dp")
            b.bind(on_release=lambda _b, i=i: self.play_index(i))
            box.add_widget(b)
        self.ids.now.text = app.player.name()

    def play_index(self, i):
        app = App.get_running_app()
        app.player.play(i)
        self.ids.now.text = app.player.name()

    def toggle(self):
        app = App.get_running_app()
        app.player.toggle()
        self.ids.now.text = app.player.name()

    def nxt(self):
        app = App.get_running_app()
        app.player.next()
        self.ids.now.text = app.player.name()

    def prv(self):
        app = App.get_running_app()
        app.player.prev()
        self.ids.now.text = app.player.name()

    def add_song(self):
        try:
            from plyer import filechooser
            filechooser.open_file(
                on_selection=self.on_picked, multiple=True, filters=["*.mp3", "*.wav", "*.ogg"]
            )
        except Exception:
            self.ids.now.text = "File picker nahi chala. 'music' folder me gaane rakhein."

    def on_picked(self, selection):
        app = App.get_running_app()
        for p in selection or []:
            app.player.add(p)
        app.store.put("songs", paths=app.player.tracks)
        Clock.schedule_once(lambda dt: self.refresh())


class ProgressScreen(Screen):
    def on_pre_enter(self, *args):
        self.show_history()

    def save(self):
        app = App.get_running_app()
        today = datetime.date.today().isoformat()
        old = app.store.get("log")["days"] if app.store.exists("log") else {}
        day = old.get(today, {"weight": "", "steps": 0, "water": 0, "workout_min": 0})
        try:
            if self.ids.weight.text:
                day["weight"] = float(self.ids.weight.text)
            if self.ids.steps.text:
                day["steps"] = int(self.ids.steps.text)
            if self.ids.water.text:
                day["water"] = int(self.ids.water.text)
        except ValueError:
            self.ids.history.text = "Sahi number daalein."
            return
        old[today] = day
        app.store.put("log", days=old)
        self.show_history()

    def show_history(self):
        app = App.get_running_app()
        if not app.store.exists("log"):
            self.ids.history.text = "Abhi tak koi record nahi."
            return
        days = app.store.get("log")["days"]
        lines = []
        for d in sorted(days, reverse=True)[:7]:
            x = days[d]
            lines.append(
                f"{d}: wazan {x['weight'] or '-'} kg | steps {x['steps']} | "
                f"pani {x['water']} glass | workout {x['workout_min']:.0f} min"
            )
        self.ids.history.text = "\n".join(lines)


# ---------------------------------------------------------------
# UI (KV)
# ---------------------------------------------------------------
KV = """
<TI@TextInput>:
    size_hint_y: None
    height: '44dp'
    multiline: False

<Btn@Button>:
    size_hint_y: None
    height: '48dp'

BoxLayout:
    orientation: 'vertical'
    ScreenManager:
        id: sm
        HealthScreen:
        WorkoutScreen:
        MusicScreen:
        ProgressScreen:
    BoxLayout:
        size_hint_y: None
        height: '52dp'
        Button:
            text: 'Health'
            on_release: sm.current = 'health'
        Button:
            text: 'Workout'
            on_release: sm.current = 'workout'
        Button:
            text: 'Music'
            on_release: sm.current = 'music'
        Button:
            text: 'Progress'
            on_release: sm.current = 'progress'

<HealthScreen>:
    name: 'health'
    BoxLayout:
        orientation: 'vertical'
        padding: '10dp'
        spacing: '6dp'
        Label:
            text: 'Smart Fitness • Health'
            font_size: '22sp'
            size_hint_y: None
            height: '40dp'
        TI:
            id: age
            hint_text: 'Umar (saal)'
            input_filter: 'int'
        TI:
            id: height
            hint_text: 'Height (cm)'
            input_filter: 'float'
        TI:
            id: weight
            hint_text: 'Wazan (kg)'
            input_filter: 'float'
        Spinner:
            id: gender
            text: 'Male'
            values: ['Male', 'Female']
            size_hint_y: None
            height: '44dp'
        Spinner:
            id: activity
            text: 'Halka active (1-3 din)'
            values: app.activity_names
            size_hint_y: None
            height: '44dp'
        Btn:
            text: 'Calculate karein'
            on_release: root.calculate()
        Label:
            id: result
            text: ''
            text_size: self.width, None
            halign: 'left'
            valign: 'top'

<WorkoutScreen>:
    name: 'workout'
    on_pre_enter: root.show_info(spin.text)
    BoxLayout:
        orientation: 'vertical'
        padding: '10dp'
        spacing: '6dp'
        Label:
            text: 'Smart Fitness • Workout'
            font_size: '22sp'
            size_hint_y: None
            height: '40dp'
        Spinner:
            id: spin
            text: app.exercise_names[0]
            values: app.exercise_names
            size_hint_y: None
            height: '44dp'
            on_text: root.show_info(self.text)
        Label:
            id: timer
            text: '00:00'
            font_size: '56sp'
            size_hint_y: None
            height: '90dp'
        BoxLayout:
            size_hint_y: None
            height: '36dp'
            CheckBox:
                id: music_on
                active: True
                size_hint_x: None
                width: '40dp'
            Label:
                text: 'Workout ke saath music chalao'
                halign: 'left'
                text_size: self.size
                valign: 'middle'
        Btn:
            id: start_btn
            text: 'Start'
            on_release: root.toggle()
        Label:
            id: info
            text: ''
            text_size: self.width, None
            halign: 'left'
            valign: 'top'

<MusicScreen>:
    name: 'music'
    BoxLayout:
        orientation: 'vertical'
        padding: '10dp'
        spacing: '6dp'
        Label:
            text: 'Smart Fitness • Music'
            font_size: '22sp'
            size_hint_y: None
            height: '40dp'
        Label:
            id: now
            text: ''
            size_hint_y: None
            height: '36dp'
        BoxLayout:
            size_hint_y: None
            height: '48dp'
            Button:
                text: '<<'
                on_release: root.prv()
            Button:
                text: 'Play / Pause'
                on_release: root.toggle()
            Button:
                text: '>>'
                on_release: root.nxt()
        Btn:
            text: '+ Gaana add karein'
            on_release: root.add_song()
        ScrollView:
            GridLayout:
                id: tracklist
                cols: 1
                spacing: '4dp'
                size_hint_y: None
                height: self.minimum_height

<ProgressScreen>:
    name: 'progress'
    BoxLayout:
        orientation: 'vertical'
        padding: '10dp'
        spacing: '6dp'
        Label:
            text: 'Smart Fitness • Progress'
            font_size: '22sp'
            size_hint_y: None
            height: '40dp'
        TI:
            id: weight
            hint_text: 'Aaj ka wazan (kg)'
            input_filter: 'float'
        TI:
            id: steps
            hint_text: 'Steps'
            input_filter: 'int'
        TI:
            id: water
            hint_text: 'Pani (glass)'
            input_filter: 'int'
        Btn:
            text: 'Save karein'
            on_release: root.save()
        Label:
            id: history
            text: ''
            text_size: self.width, None
            halign: 'left'
            valign: 'top'
"""


# ---------------------------------------------------------------
# App
# ---------------------------------------------------------------
class FitnessApp(App):
    exercise_names = list(EXERCISES.keys())
    activity_names = list(ACTIVITY.keys())

    def build(self):
        self.title = "Smart Fitness"
        self.store = JsonStore(os.path.join(self.user_data_dir, "fitlife.json"))
        self.player = MusicPlayer()
        # 1) app ke saath bundled 'music' folder
        self.player.load_folder(os.path.join(os.path.dirname(__file__), "music"))
        # 2) user ne jo gaane add kiye the
        if self.store.exists("songs"):
            for p in self.store.get("songs")["paths"]:
                self.player.add(p)
        self.request_android_permissions()
        return Builder.load_string(KV)

    def request_android_permissions(self):
        try:
            from android.permissions import Permission, request_permissions
            request_permissions([
                Permission.READ_EXTERNAL_STORAGE,
                "android.permission.READ_MEDIA_AUDIO",
            ])
        except ImportError:
            pass  # desktop par chalane par

    def add_workout_minutes(self, mins):
        today = datetime.date.today().isoformat()
        old = self.store.get("log")["days"] if self.store.exists("log") else {}
        day = old.get(today, {"weight": "", "steps": 0, "water": 0, "workout_min": 0})
        day["workout_min"] = day.get("workout_min", 0) + mins
        old[today] = day
        self.store.put("log", days=old)

    def on_pause(self):
        return True  # background me bhi music chalta rahe


if __name__ == "__main__":
    FitnessApp().run()
