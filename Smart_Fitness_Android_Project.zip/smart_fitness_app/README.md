# Smart Fitness — Android app project

This is a Kivy-based Android project built from the supplied Python code. It includes:
- Health estimates/profile storage
- Exercise guide and countdown timer
- Music controls and song picker
- Daily progress history

## Build an APK (Linux / Ubuntu)

1. Install Python 3, Java 17, and the Android build dependencies listed in the official Buildozer installation guide: https://buildozer.readthedocs.io/en/latest/installation.html
2. Extract this folder and open a terminal in it.
3. Run:

   ```bash
   pip install --user buildozer
   buildozer android debug
   ```

4. The APK will be created in `bin/`. For a release APK/AAB, configure a private signing key and follow the current Google Play release requirements.

## Notes
- The supplied environment did not have Buildozer, Kivy, or Android SDK tools installed, so an APK could not be compiled in this workspace. This project is prepared for building; the ZIP is not itself an APK.
- Before publishing, test on real Android devices, especially music file selection and playback. Android audio/storage permissions differ by OS version.
- Health values are rough estimates, not medical advice. For users under 18, the app avoids adult BMI categories and calorie targets.
- Do not include copyrighted music files unless you have the rights to distribute them. The `music/` folder is intentionally empty.
