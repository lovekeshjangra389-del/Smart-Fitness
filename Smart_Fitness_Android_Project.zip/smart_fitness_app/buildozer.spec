[app]
title = Smart Fitness
package.name = smartfitness
package.domain = com.smartfitness.app
source.dir = .
source.include_exts = py,kv,png,jpg,jpeg,ogg,mp3,wav
version = 1.0.0
requirements = python3,kivy,plyer
orientation = portrait
fullscreen = 0
icon.filename = %(source.dir)s/icon.png

# Android configuration
android.api = 35
android.minapi = 23
android.ndk = 27c
android.archs = arm64-v8a, armeabi-v7a
android.permissions = READ_MEDIA_AUDIO,READ_EXTERNAL_STORAGE
android.accept_sdk_license = True

# App metadata
presplash.filename = %(source.dir)s/icon.png

[buildozer]
log_level = 2
warn_on_root = 1
